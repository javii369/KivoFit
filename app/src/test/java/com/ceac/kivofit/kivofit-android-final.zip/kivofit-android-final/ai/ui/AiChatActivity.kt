package com.ceac.kivofit.ai.ui

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ceac.kivofit.R
import com.ceac.kivofit.ai.api.ApiClient
import com.ceac.kivofit.ai.repository.AiRepository
import com.ceac.kivofit.ai.ui.adapter.ChatAdapter
import com.ceac.kivofit.ai.viewmodel.AiChatViewModel
import com.ceac.kivofit.ai.viewmodel.AiChatViewModelFactory
import com.google.android.material.appbar.MaterialToolbar

class AiChatActivity : AppCompatActivity() {
    
    private lateinit var viewModel: AiChatViewModel
    private lateinit var chatAdapter: ChatAdapter
    
    private lateinit var toolbar: MaterialToolbar
    private lateinit var recyclerView: RecyclerView
    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_chat)
        
        initViews()
        setupToolbar()
        setupViewModel()
        setupRecyclerView()
        setupListeners()
        observeViewModel()
        
        // Iniciar nueva conversación al abrir
        viewModel.startNewConversation()
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        recyclerView = findViewById(R.id.recyclerViewMessages)
        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }
    
    private fun setupViewModel() {
        val repository = AiRepository(ApiClient.aiApiService)
        val factory = AiChatViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[AiChatViewModel::class.java]
    }
    
    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter()
        recyclerView.apply {
            adapter = chatAdapter
            layoutManager = LinearLayoutManager(this@AiChatActivity).apply {
                stackFromEnd = true
            }
        }
    }
    
    private fun setupListeners() {
        // Botón de enviar
        buttonSend.setOnClickListener {
            sendMessage()
        }
        
        // Enter en el teclado
        editTextMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }
    }
    
    private fun sendMessage() {
        val message = editTextMessage.text.toString()
        if (message.isNotBlank()) {
            viewModel.sendMessage(message)
            editTextMessage.text?.clear()
            
            // Ocultar teclado
            editTextMessage.clearFocus()
        }
    }
    
    private fun observeViewModel() {
        // Observar mensajes
        viewModel.messages.observe(this) { messages ->
            chatAdapter.submitList(messages) {
                // Scroll al último mensaje después de actualizar
                if (messages.isNotEmpty()) {
                    recyclerView.smoothScrollToPosition(messages.size - 1)
                }
            }
        }
        
        // Observar título de conversación
        viewModel.conversationTitle.observe(this) { title ->
            supportActionBar?.title = title
        }
        
        // Observar estado de carga
        viewModel.isLoading.observe(this) { isLoading ->
            buttonSend.isEnabled = !isLoading
            editTextMessage.isEnabled = !isLoading
        }
        
        // Observar errores
        viewModel.error.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
                viewModel.clearError()
            }
        }
    }
}
