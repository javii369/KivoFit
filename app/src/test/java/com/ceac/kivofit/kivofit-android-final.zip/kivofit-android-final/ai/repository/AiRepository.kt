package com.ceac.kivofit.ai.repository

import com.ceac.kivofit.ai.api.AiApiService
import com.ceac.kivofit.ai.api.SendMessageRequest
import com.ceac.kivofit.ai.models.Conversation
import com.ceac.kivofit.ai.models.Message
import com.ceac.kivofit.ai.models.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AiRepository(private val apiService: AiApiService) {
    
    suspend fun createConversation(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.createConversation()
            if (response.isSuccessful && response.body()?.success == true) {
                Result.success(response.body()!!.conversation.id)
            } else {
                Result.failure(Exception("Error al crear conversación: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun sendMessage(
        conversationId: String,
        message: String
    ): Result<Message> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.sendMessage(
                conversationId,
                SendMessageRequest(message)
            )
            
            if (response.isSuccessful && response.body()?.success == true) {
                val body = response.body()!!
                if (body.message != null) {
                    val msg = Message(
                        id = body.message.id,
                        role = MessageRole.ASSISTANT,
                        content = body.message.content,
                        createdAt = body.message.created_at
                    )
                    Result.success(msg)
                } else {
                    Result.failure(Exception("No se recibió respuesta del asistente"))
                }
            } else {
                val errorMsg = response.body()?.error ?: response.message()
                Result.failure(Exception("Error: $errorMsg"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Error de red: ${e.message}"))
        }
    }
    
    suspend fun getConversationHistory(
        conversationId: String
    ): Result<Pair<String?, List<Message>>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getConversationHistory(conversationId)
            if (response.isSuccessful && response.body()?.success == true) {
                val conversation = response.body()!!.conversation
                val messages = conversation.messages.map { msg ->
                    Message(
                        id = msg.id,
                        role = if (msg.role == "user") MessageRole.USER else MessageRole.ASSISTANT,
                        content = msg.content,
                        createdAt = msg.created_at
                    )
                }
                Result.success(Pair(conversation.title, messages))
            } else {
                Result.failure(Exception("Error al cargar historial: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun getConversations(): Result<List<Conversation>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getConversations()
            if (response.isSuccessful && response.body()?.success == true) {
                val conversations = response.body()!!.conversations.map { item ->
                    Conversation(
                        id = item.id,
                        title = item.title,
                        messageCount = item.message_count,
                        updatedAt = item.updated_at
                    )
                }
                Result.success(conversations)
            } else {
                Result.failure(Exception("Error al cargar conversaciones: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun deleteConversation(conversationId: String): Result<Unit> = 
        withContext(Dispatchers.IO) {
            try {
                val response = apiService.deleteConversation(conversationId)
                if (response.isSuccessful && response.body()?.success == true) {
                    Result.success(Unit)
                } else {
                    Result.failure(Exception("Error al eliminar conversación: ${response.message()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
