package com.ceac.kivofit.ai.models

data class Message(
    val id: Long? = null,
    val role: MessageRole,
    val content: String,
    val createdAt: String? = null,
    val isLoading: Boolean = false
)

enum class MessageRole {
    USER,
    ASSISTANT;
    
    override fun toString(): String {
        return name.lowercase()
    }
}
