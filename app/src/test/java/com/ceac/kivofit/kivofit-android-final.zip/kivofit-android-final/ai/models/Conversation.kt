package com.ceac.kivofit.ai.models

data class Conversation(
    val id: String,
    val title: String,
    val messageCount: Int,
    val updatedAt: String
)
