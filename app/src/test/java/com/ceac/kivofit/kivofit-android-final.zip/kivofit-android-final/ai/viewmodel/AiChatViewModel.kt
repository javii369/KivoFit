package com.ceac.kivofit.ai.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ceac.kivofit.ai.models.Message
import com.ceac.kivofit.ai.models.MessageRole
import com.ceac.kivofit.ai.repository.AiRepository
import kotlinx.coroutines.launch

class AiChatViewModel(private val repository: AiRepository) : ViewModel() {
    
    private val _messages = MutableLiveData<List<Message>>(emptyList())
    val messages: LiveData<List<Message>> = _messages
    
    private val _conversationTitle = MutableLiveData<String>()
    val conversationTitle: LiveData<String> = _conversationTitle
    
    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error
    
    private var currentConversationId: String? = null
    
    /**
     * Iniciar una nueva conversación
     */
    fun startNewConversation() {
        viewModelScope.launch {
            _isLoading.value = true
            repository.createConversation()
                .onSuccess { conversationId ->
                    currentConversationId = conversationId
                    _messages.value = emptyList()
                    _conversationTitle.value = "Nueva conversación"
                    _error.value = null
                }
                .onFailure { exception ->
                    _error.value = exception.message ?: "Error al crear conversación"
                }
            _isLoading.value = false
        }
    }
    
    /**
     * Enviar un mensaje al asistente
     */
    fun sendMessage(messageText: String) {
        if (currentConversationId == null) {
            _error.value = "No hay conversación activa"
            return
        }
        
        if (messageText.isBlank()) return
        
        // Agregar mensaje del usuario a la UI
        val userMessage = Message(
            role = MessageRole.USER,
            content = messageText
        )
        
        val currentMessages = _messages.value.orEmpty().toMutableList()
        currentMessages.add(userMessage)
        
        // Agregar indicador de "escribiendo..."
        val loadingMessage = Message(
            role = MessageRole.ASSISTANT,
            content = "Escribiendo...",
            isLoading = true
        )
        currentMessages.add(loadingMessage)
        _messages.value = currentMessages
        
        viewModelScope.launch {
            repository.sendMessage(currentConversationId!!, messageText)
                .onSuccess { assistantMessage ->
                    // Remover mensaje de carga y agregar respuesta real
                    val updatedMessages = _messages.value.orEmpty().toMutableList()
                    updatedMessages.removeAt(updatedMessages.lastIndex) // Remover loading
                    
                    updatedMessages.add(assistantMessage)
                    _messages.value = updatedMessages
                    _error.value = null
                }
                .onFailure { exception ->
                    // Remover mensaje de carga en caso de error
                    val updatedMessages = _messages.value.orEmpty().toMutableList()
                    if (updatedMessages.isNotEmpty()) {
                        updatedMessages.removeAt(updatedMessages.lastIndex)
                    }
                    _messages.value = updatedMessages
                    
                    _error.value = exception.message ?: "Error al enviar mensaje"
                }
        }
    }
    
    /**
     * Cargar una conversación existente
     */
    fun loadConversation(conversationId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            repository.getConversationHistory(conversationId)
                .onSuccess { (title, messages) ->
                    currentConversationId = conversationId
                    _conversationTitle.value = title ?: "Conversación"
                    _messages.value = messages
                    _error.value = null
                }
                .onFailure { exception ->
                    _error.value = exception.message ?: "Error al cargar conversación"
                }
            _isLoading.value = false
        }
    }
    
    /**
     * Limpiar el error actual
     */
    fun clearError() {
        _error.value = null
    }
    
    /**
     * Obtener el ID de la conversación actual
     */
    fun getCurrentConversationId(): String? = currentConversationId
}
