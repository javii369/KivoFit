package com.ceac.kivofit.ai.api

import retrofit2.Response
import retrofit2.http.*

interface AiApiService {
    
    @POST("ai/conversations")
    suspend fun createConversation(): Response<ConversationResponse>
    
    @GET("ai/conversations")
    suspend fun getConversations(): Response<ConversationsListResponse>
    
    @GET("ai/conversations/{conversationId}")
    suspend fun getConversationHistory(
        @Path("conversationId") conversationId: String
    ): Response<ConversationHistoryResponse>
    
    @POST("ai/conversations/{conversationId}/messages")
    suspend fun sendMessage(
        @Path("conversationId") conversationId: String,
        @Body request: SendMessageRequest
    ): Response<MessageResponse>
    
    @DELETE("ai/conversations/{conversationId}")
    suspend fun deleteConversation(
        @Path("conversationId") conversationId: String
    ): Response<DeleteResponse>
}

// Request/Response Data Classes

data class SendMessageRequest(
    val message: String
)

data class ConversationResponse(
    val success: Boolean,
    val conversation: ConversationData
)

data class ConversationData(
    val id: String,
    val created_at: String
)

data class MessageResponse(
    val success: Boolean,
    val message: MessageData?,
    val usage: UsageData?,
    val error: String?
)

data class MessageData(
    val id: Long,
    val role: String,
    val content: String,
    val created_at: String
)

data class UsageData(
    val model: String,
    val input_tokens: Int,
    val output_tokens: Int
)

data class ConversationHistoryResponse(
    val success: Boolean,
    val conversation: ConversationHistoryData
)

data class ConversationHistoryData(
    val id: String,
    val title: String?,
    val created_at: String,
    val messages: List<MessageData>
)

data class ConversationsListResponse(
    val success: Boolean,
    val conversations: List<ConversationItem>
)

data class ConversationItem(
    val id: String,
    val title: String,
    val message_count: Int,
    val updated_at: String
)

data class DeleteResponse(
    val success: Boolean,
    val message: String
)
