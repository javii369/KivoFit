# 🚀 INSTALACIÓN RÁPIDA - ASISTENTE IA KIVOFIT

## ✅ PASO 1: Agregar Dependencias

Abre `app/build.gradle.kts` y agrega en `dependencies`:

```kotlin
dependencies {
    // ... tus dependencias existentes ...
    
    // ASISTENTE IA
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
```

**Haz clic en "Sync Now"**

---

## ✅ PASO 2: Copiar Archivos

### Archivos Kotlin (.kt)

Copia TODA la carpeta `ai/` a:
```
app/src/main/java/com/ceac/kivofit/
```

Deberías tener:
```
app/src/main/java/com/ceac/kivofit/
└── ai/
    ├── api/
    │   ├── AiApiService.kt
    │   └── ApiClient.kt
    ├── models/
    │   ├── Message.kt
    │   └── Conversation.kt
    ├── repository/
    │   └── AiRepository.kt
    ├── viewmodel/
    │   ├── AiChatViewModel.kt
    │   └── AiChatViewModelFactory.kt
    └── ui/
        ├── AiChatActivity.kt
        └── adapter/
            └── ChatAdapter.kt
```

### Archivos XML

Copia los archivos de `res/layout/` a:
```
app/src/main/res/layout/
```

- `activity_ai_chat.xml`
- `item_message_user.xml`
- `item_message_assistant.xml`

### Colores

Abre `app/src/main/res/values/colors.xml` y agrega:

```xml
<color name="user_message_bg">#6200EE</color>
<color name="assistant_message_bg">#FFFFFF</color>
<color name="background">#F5F5F5</color>
<color name="text_primary">#212121</color>
<color name="primary">#6200EE</color>
```

---

## ✅ PASO 3: Actualizar AndroidManifest.xml

Agrega PERMISOS (antes de `<application>`):

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

Agrega la ACTIVITY (dentro de `<application>`):

```xml
<activity
    android:name=".ai.ui.AiChatActivity"
    android:exported="false"
    android:screenOrientation="portrait"
    android:windowSoftInputMode="adjustResize" />
```

---

## ✅ PASO 4: Crear Iconos

En Android Studio:
- Right-click en `res` → **New → Vector Asset**
- Crear `ic_arrow_back` (buscar "arrow back")
- Crear `ic_send` (buscar "send")

---

## ✅ PASO 5: Configurar URL del Backend

Abre `ai/api/ApiClient.kt` y cambia la URL:

```kotlin
// Si tienes backend:
private const val BASE_URL = "https://api-kivofit.com/api/"

// Para desarrollo local (emulador):
// private const val BASE_URL = "http://10.0.2.2:8000/api/"

// Para desarrollo local (dispositivo físico):
// private const val BASE_URL = "http://192.168.1.XXX:8000/api/"
```

---

## ✅ PASO 6: Probar la Activity

Desde cualquier Activity, abre el chat:

```kotlin
val intent = Intent(this, AiChatActivity::class.java)
startActivity(intent)
```

---

## ✅ PASO 7: Build y Ejecutar

1. Build → Make Project
2. Run App
3. ¡Deberías ver la pantalla del chat!

---

## 🔧 SI EL BACKEND NO ESTÁ LISTO

Puedes crear datos MOCK para probar la UI. En `AiRepository.kt`, método `sendMessage`:

```kotlin
suspend fun sendMessage(conversationId: String, message: String): Result<Message> {
    // MOCK temporal
    delay(1000)
    val mockResponse = Message(
        id = System.currentTimeMillis(),
        role = MessageRole.ASSISTANT,
        content = "Esta es una respuesta de prueba. El backend se conectará pronto.",
        createdAt = "2024-05-06T10:00:00"
    )
    return Result.success(mockResponse)
}
```

---

## ✅ CHECKLIST FINAL

- [ ] Dependencias agregadas en build.gradle.kts
- [ ] Carpeta `ai/` copiada
- [ ] Layouts XML copiados
- [ ] Colores agregados
- [ ] AndroidManifest.xml actualizado
- [ ] Iconos creados
- [ ] URL del backend configurada
- [ ] Build exitoso
- [ ] App ejecutándose

---

¡Listo! Tu parte del asistente IA está completa 🎉
